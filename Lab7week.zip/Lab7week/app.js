const express = require('express');
const bodyParser = require('body-parser');
const { default: mongoose } = require('mongoose');
const bcrypt = require('bcryptjs');
const session = require('express-session');
const _ = require('lodash');

const app = express();

app.set('view engine', 'ejs');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static("public"));

app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: false
}));

mongoose.connect("mongodb+srv://darina:hello@cluster0.wkd57.mongodb.net/todolist?retryWrites=true&w=majority")
    .then(() => console.log("Connected to MongoDB Atlas"))
    .catch((err) => console.log("MongoDB Atlas connection error: ", err));


const userSchema = new mongoose.Schema({
    username: String,
    password: String
});

const User = mongoose.model("User", userSchema);

(async () => {
    try {
        const existingUser = await User.findOne({ username: 'darina' });

        if (!existingUser) {
            const hashedPassword = await bcrypt.hash('hello', 10);
            const newUser = new User({ username: 'darina', password: hashedPassword });
            await newUser.save();
            console.log('User "darina" has been successfully registered!');
        } else {
            console.log('User "darina" already exists in the database.');
        }
    } catch (error) {
        console.error('Error creating user "darina":', error);
    }
})();


const itemsSchema = {
    name: String
};

const Item = mongoose.model("Item", itemsSchema);

// Default ToDo items
const item1 = new Item({ name: "Welcome to your ToDo list!" });
const item2 = new Item({ name: "Create a ToDo list" });
const item3 = new Item({ name: "Do homework" });
const defaultItems = [item1, item2, item3];

// Define list schema
const listSchema = {
    name: String,
    items: [itemsSchema],
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
};

const List = mongoose.model("List", listSchema);

// Routes

// Home route - check for login status
app.get("/", (req, res) => {
    if (req.session.userId) {
        res.redirect("/" + req.session.username);
    } else {
        res.render("list", { listTitle: "Home", newListItems: defaultItems });
    }
});

app.get("/about", (req, res) => {
    res.render("about");
});

app.get("/work", (req, res) => {
    res.render("work");
});

app.get("/login", (req, res) => {
    res.render("login");
});

app.post("/login", async (req, res) => {
    const { username, password } = req.body;

    try {
        const user = await User.findOne({ username });

        if (user) {
            const isPasswordCorrect = await bcrypt.compare(password, user.password);

            if (isPasswordCorrect) {
                req.session.userId = user._id;
                req.session.username = user.username;
                res.redirect("/" + username);
            } else {
                res.send("Incorrect password!");
            }
        } else {
            res.send("No user found with that username.");
        }
    } catch (err) {
        console.log(err);
    }
});

// Route to display the profile page
app.get("/profile", async (req, res) => {
    if (req.session.userId) {
        const user = await User.findById(req.session.userId);
        res.render("profile", { username: user.username });
    } else {
        res.redirect("/login");
    }
});

app.post("/profile", async (req, res) => {
    const { newUsername, newPassword } = req.body;

    try {
        const user = await User.findById(req.session.userId);
        
        if (newUsername) {
            user.username = newUsername;
        }

        if (newPassword) {
            const hashedPassword = await bcrypt.hash(newPassword, 10);
            user.password = hashedPassword;
        }

        await user.save();
        res.redirect("/profile"); 
    } catch (err) {
        console.log(err);
        res.send("Error updating profile");
    }
});


// Signup route
app.get("/signup", (req, res) => {
    res.render("signup");
});

app.post("/signup", async (req, res) => {
    const { username, password } = req.body;

    try {
        const hashedPassword = await bcrypt.hash(password, 10);

        const newUser = new User({
            username,
            password: hashedPassword
        });

        await newUser.save();
        res.redirect("/login");
    } catch (err) {
        console.log(err);
    }
});

app.post("/", async function(req, res) {
    try {
        const itemName = req.body.newItem;
        const listName = req.body.list;

        const item = new Item({ name: itemName });

        if (listName === "Home") {
            await item.save();
            res.redirect("/");
        } else {
            const foundList = await List.findOne({ name: listName, userId: req.session.userId });
            foundList.items.push(item);
            await foundList.save();
            res.redirect("/" + listName);
        }
    } catch (err) {
        console.log(err);
    }
});

// Delete item route
app.post("/delete", async function(req, res) {
    try {
        const checkedItemId = req.body.checkbox;
        const listName = req.body.listName;

        if (listName === "Home") {
            await Item.findByIdAndDelete(checkedItemId);
            res.redirect("/");
        } else {
            await List.findOneAndUpdate(
                { name: listName, userId: req.session.userId },
                { $pull: { items: { _id: checkedItemId } } }
            );
            res.redirect("/" + listName);
        }
    } catch (err) {
        console.log(err);
    }
});

// Custom list route
app.get("/:customListName", async function(req, res) {
    try {
        const customListName = _.capitalize(req.params.customListName);
        const foundList = await List.findOne({ name: customListName, userId: req.session.userId }).exec();

        if (!foundList) {
            const list = new List({
                name: customListName,
                items: defaultItems,
                userId: req.session.userId
            });
            await list.save();
            res.redirect("/" + customListName);
        } else {
            res.render("list", { listTitle: foundList.name, newListItems: foundList.items });
        }
    } catch (err) {
        console.log(err);
    }
});

app.get("/logout", (req, res) => {
    req.session.destroy(() => {
        res.redirect("/login");
    });
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
